## w -> move up
## s -> move down
## a -> move left
## d -> move right

## e -> heal spell
## r -> Have spell

## x -> king attacks with a axe
## ' ' -> for king to attack

## 1 -> spwaning point 1
## 2 -> spwaning point 2
## 3 -> spwaning point 3