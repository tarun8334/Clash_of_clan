import os
from re import X
import time
from colorama import init, Fore, Back, Style

from object import scenery

from object import scenery
from object import obs
from board import *

class spell:
    def rage(kp):
        kp=kp*2
        return kp